import Box from '@mui/material/Box'
import Container from '@mui/material/Container'
import { useState } from 'react'
import { useSelector } from 'react-redux'
import useBranches from '../branches/branchesData'
import useCanal from '../canals/CanalsData'
import Waiting from '../common/Waiting'
import useSale from './SaleData'
import SalesDetail from './SalesDetail'
import SalesTable from './SalesTable'
import Toolbar from './Toolbar'

const SalesView = () => {
	const [view, setView] = useState('table')
	const [sale, setSale] = useState({})
	const [newSale, setNewSale] = useState(false)
	const { user } = useSelector((state) => state.user.user.data)
	const { branches } = useBranches()

	const { canals } = useCanal()

	const [dateRange, setDateRange] = useState(null)
	console.log('date range: ', dateRange)
	const { loading, sales } = useSale(
		dateRange
			? `?limit=10000&&sort=-week&&initDate=${dateRange.initDate.format(
					'YYYY-MM-DD HH:mm ZZ'
			  )}&&endDate=${dateRange.endDate.format('YYYY-MM-DD HH:mm ZZ')}`
			: `?limit=10000&&sort=-week` //&&initDate=${startOfWeek}&&endDate=${endOfWeek}`
	)

	const userBranch = user.positions
	const userRoles = user.roles
	const BranchArray = []

	userBranch.forEach((element) => {
		BranchArray.push(element.branch?._id)
	})

	//console.log('SALES: ', sales)

	const renderContent = () => {
		switch (view) {
			case 'table':
				return (
					<SalesTable
						setSale={setSale}
						setView={setView}
						sales={sales}
						userRoles={userRoles}
						BranchArray={BranchArray}
						dateRange={dateRange}
					/>
				)
			case 'detail':
				return (
					<SalesDetail
						newSale={newSale}
						setNewSale={setNewSale}
						sale={sale}
						setSale={setSale}
						setView={setView}
						branches={branches}
						canals={canals}
						userBranches={BranchArray}
						userRoles={userRoles}
					/>
				)
			default:
				break
		}
	}

	return (
		<Container maxWidth={false}>
			<Box mt={3}>
				{' '}
				{/* <Typography variant='h2'>Providers</Typography> */}{' '}
				<Toolbar
					setView={setView}
					view={view}
					setNewSale={setNewSale}
					setSale={setSale}
					dateRange={dateRange}
					setDateRange={setDateRange}
				/>{' '}
			</Box>{' '}
			<Box mt={3}> {loading ? <Waiting /> : renderContent()} </Box>{' '}
		</Container>
	)
}

export default SalesView