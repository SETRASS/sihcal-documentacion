import {
	createDailySale,
	createDailySaleByFile,
	updateDailySale,
} from '@/adapters/dailysales'
import CloudUploadIcon from '@mui/icons-material/CloudUpload'
import SendIcon from '@mui/icons-material/Send'
import { LoadingButton } from '@mui/lab'
import {
	Box,
	Button,
	FormControlLabel,
	Grid,
	InputAdornment,
	Radio,
	RadioGroup,
	TextField,
	Typography,
} from '@mui/material'
import { styled } from '@mui/system'
import { isEmpty } from 'lodash'
import moment from 'moment'
import 'moment/locale/es' // without this line it didn't work
import PropTypes from 'prop-types'
import { useState } from 'react'
import { ExcelRenderer, OutTable } from 'react-excel-renderer'
import { useDispatch, useSelector } from 'react-redux'
import { useNavigate } from 'react-router-dom'
import { errorActions } from '../../redux/ducks/errorState'
import FilesView from '../common/Files'
import SelectDate from '../common/SelectDate'


moment.locale('es')

const allAccess = ['owner', 'hr', 'admin']

const Container = styled('div')(({ theme }) => ({
	width: '100%',
	margin: 'auto',
	padding: '20px',
	backgroundColor: theme.palette.background.paper,
	borderRadius: '8px',
	boxShadow: '0 0 10px rgba(0, 0, 0, 0.1)',
}))

const Header = styled('div')(({ theme }) => ({
	display: 'flex',
	justifyContent: 'space-between',
	alignItems: 'center',
	borderBottom: `3px solid ${theme.palette.primary.main}`,
	paddingBottom: '10px',
	marginBottom: '20px',
}))

const StyledButton = styled(Button)(({ theme }) => ({
	backgroundColor: theme.palette.primary.main,
	color: 'white',
	padding: '13px',
	textAlign: 'center',
}))

const DailySalesDetail = ({
	className,
	dailySale,
	setDailySale,
	newDailySale,
	setNewDailySale,
	setView,
	branches,
	userBranches,
	userRoles,
	canals,
	...rest
}) => {
	const dispatch = useDispatch()
	const navigate = useNavigate()

	const [flatSend, setFlatSend] = useState(true) //cuando es enviado por archivo excel
	const [valueRadio, setValueRadio] = useState(
		dailySale._id ? 'manual' : 'excel'
	) //para el control del radioButton

	const currentUser = useSelector((state) => state.user.user.data.user)
	const currentTenant = useSelector((state) => state.tenant)

	const [branchOptions] = useState(
		currentUser.roles.some((rol) => allAccess.includes(rol)) //si alguno (some) de los roles del usuario pertenece a los definidos en allAccess, devuelvo "true"
			? [...branches] //ve todas las sucursales
			: branches.filter((branch) => userBranches.includes(branch?._id)) //tiene que ver solo sus sucursales
	)

	const [branch, setBranch] = useState(
		dailySale._id ? dailySale.branch : branchOptions[0]._id
	)
	const [isSubmitting, setIsSubmitting] = useState(false)
	const [atm, setAtm] = useState(dailySale?.atm || 0)
	const [cash, setCash] = useState(dailySale?.cash || 0)
	const [tax, setTax] = useState(dailySale?.tax || 0)
	const [tips_payed, setTips_payed] = useState(dailySale?.tips_payed || 0)
	const [discount, setDiscount] = useState(dailySale?.discount || 0)
	const [canal, setCanal] = useState(canals[0]?._id)
	const [comment, setComment] = useState(dailySale?.comment || '')

	const [files, setFiles] = useState(dailySale.files ? dailySale.files : [])
	const [date, setDate] = useState(
		dailySale._id ? moment(dailySale.date) : moment()
	)

	const isSame =
		atm == dailySale?.atm &&
		cash == dailySale?.cash &&
		tax == dailySale?.tax &&
		tips_payed == dailySale?.tips_payed &&
		discount == dailySale?.discount &&
		comment == dailySale?.comment &&
		branch == dailySale?.branch &&
		date.format() == moment(dailySale?.date).format()


	let disabled =
		isSame || isSubmitting || parseFloat(atm) + parseFloat(cash) <= 0

	let canalsArray = []
	const LimitedAccess = ['senior', 'manager', 'branch'] // solo pueden ver las ventas de su propia branch

	canals.map((b) => canalsArray.push({ id: b._id, name: b.name }))
	const [uploadCustomer, setUploadCustomer] = useState({ cols: '', rows: '' })

	const handleChangeRadio = (event) => {
		setValueRadio(event.target.value)
	}

	const handleCancel = () => {
		setNewDailySale(false)
		setDailySale({})
		navigate(0)
	}

	const handleBranchChange = (event) => {
		if (dailySale._id) {
			// en caso de editar uno existente
			setDailySale({ ...dailySale, branch: event.target.value })
		} else {
			//en caso de crear uno nuevo
			setBranch(event.target.value)
		}
	}

	const handleDateChange = (event) => {
		if (dailySale._id) {
			// en caso de editar uno existente
			setDailySale({
				...dailySale,
				date: moment(event)
					.tz(currentTenant.config.config.timezone)
					.startOf('day'),
			})
		} else {
			//en caso de crear uno nuevo
			setDate(
				moment(event)
					.tz(currentTenant.config.config.timezone)
					.startOf('day')
			)
		}
	}

	const handleCanalChange = (event) => {
		setCanal(event.target.value)
	}

	const handleAtmChange = (event) => setAtm(event.target.value)

	const handleCashChange = (event) => setCash(event.target.value)

	const handleTaxChange = (event) => setTax(event.target.value)

	const handleTipsChange = (event) => setTips_payed(event.target.value)

	const handleDiscountChange = (event) => setDiscount(event.target.value)

	const handleComment = (event) => setComment(event.target.value)

	let branchesArray = []
	let canales = []

	branches.map((b) => branchesArray.push({ id: b._id, name: b.name }))

	branchesArray = currentUser.roles.some((rol) => LimitedAccess.includes(rol))
		? branchesArray.filter((saleE) => userBranches.includes(saleE.id)) //tiene que ver solo sus sucursales
		: branchesArray //ve todas las sucursales

	canals.map((can) =>
		canales.push({ id: can._id, name: can.name, amount: 0 })
	)

	if (isEmpty(dailySale) && !newDailySale) return <div />

	//funcion para subir excel de clientes
	const fileHandler = (event) => {
		let fileObj = event.target.files[0]

		//just pass the fileObj as parameter
		ExcelRenderer(fileObj, (err, resp) => {
			if (err) {
				console.log(err)
			} else {
				setUploadCustomer({
					cols: resp.cols,
					rows: resp.rows,
				})
			}

			setFlatSend(false)
		})
	}


	const handleSubmit = async () => {
		// en caso de crear manualmente
		if (valueRadio === 'manual') {
			try {
				setIsSubmitting(true)


				const values = {

					branch,
					atm,
					cash,
					tax,
					comment,
					tips_payed,
					discount,
					date,
					groosTotal: parseFloat(+atm + +cash),
					netSale: parseFloat(
						+atm + +cash - +tax - +tips_payed - +discount
					),
					manual: true,
					canal: canalsArray[0]?.id, //In House
				}

				if (dailySale._id) {
					//en caso de estar editando
					values.date = dailySale.date
					await updateDailySale(dailySale._id, values)

				} else {
					// en caso de crear uno nuevo
					let result = await createDailySale(values)
					setDailySale(result.data.data.data)
				}

				setIsSubmitting(false)
				dispatch(
					errorActions.setError(
						{
							message: 'The DailySale has been saved!',
						},
						true
					)
				)
			} catch (err) {
				console.log('Error saving Daily Sale: ', err)
				dispatch(
					errorActions.setError({
						message: err.response?.data
							? err.response.data.message
							: 'There was an error on the backend',
					})
				)
				setIsSubmitting(false)
			}
		} else {
			//en caso de crear via Excel

			setIsSubmitting(true)
			//en caso de enviar un file
			if (!flatSend) {
				const values = {
					branch: branch,
					canal: canal,
					date: date,
				}
				const sendfileData = new FormData()
				sendfileData.append('file', uploadCustomer)

				values.file = uploadCustomer

				await createDailySaleByFile(values)

				setIsSubmitting(false)
				dispatch(
					errorActions.setError(
						{
							message: 'The DailySale has been saved!',
						},
						true
					)
				)
				navigate(0)
			}
		}
	}

	return (
		<Container>
			<Header>
				<Typography variant='h4'>
					{dailySale._id ? 'Edit DailySale' : 'New DailySale'}
				</Typography>
				<RadioGroup row value={valueRadio} onChange={handleChangeRadio}>
					<FormControlLabel
						disabled={dailySale._id}
						value='excel'
						control={<Radio />}
						label='Excel'
					/>
					<FormControlLabel
						disabled={dailySale._id}
						value='manual'
						control={<Radio />}
						label='Manual'
					/>
				</RadioGroup>
			</Header>

			{/* <Divider /> */}

			<Box>
				{valueRadio === 'excel' ? (
					<Grid container spacing={3} sx={{ mt: 3 }}>
						<Grid item md={4} xs={12}>
							<TextField
								fullWidth
								label='Branch'
								name='branch'
								onChange={handleBranchChange}
								required
								value={branch?._id}
								variant='outlined'
								select
								SelectProps={{
									native: true,
								}}
							>
								{branchOptions.map((branch) => (
									<option
										key={branch?._id}
										value={branch?._id}
									>
										{branch?.name}
									</option>
								))}
							</TextField>
						</Grid>

						<Grid item md={4} xs={12}>
							<SelectDate
								label='Date'
								value={date}
								onChange={handleDateChange}
								fullWidth
							/>
						</Grid>

						<Grid item md={4} xs={12}>
							<TextField
								fullWidth
								disabled={dailySale._id}
								name='canal'
								onChange={(event) =>
									handleCanalChange(event.target)
								}
								required
								variant='outlined'
								select
								SelectProps={{
									native: true,
								}}
							>
								{canalsArray.map((canal) => (
									<option key={canal.id} value={canal.id}>
										{canal.name}
									</option>
								))}
							</TextField>
						</Grid>
						<Grid item md={4} xs={12}>
							<input
								accept='.xlsx'
								style={{ display: 'none' }}
								id='contained-button-file'
								type='file'
								onChange={fileHandler}
							/>
							<label htmlFor='contained-button-file'>
								<Button
									fullWidth
									startIcon={<CloudUploadIcon />}
									variant='contained'
									color='primary'
									component='span'
								>
									Upload
								</Button>
							</label>
						</Grid>

						<Grid item md={4} xs={12}>
							<Button
								variant='contained'
								color='primary'
								onClick={handleSubmit}
								disabled={flatSend}
								endIcon={<SendIcon />}
							>
								Send FILE
							</Button>
						</Grid>

						<Grid item container spacing={3}>
							<Grid item md={12} xs={12}>
								<Typography variant='h4'>
									Please upload an Excel(.xlsx) File
								</Typography>
							</Grid>

							{uploadCustomer.rows === '' ? null : (
								<Grid item md={12} xs={12}>
									<OutTable
										className='table table-responsive'
										data={uploadCustomer.rows}
										columns={uploadCustomer.cols}
										tableClassName='table table-responsive'
										tableHeaderRowClass='heading'
									/>
								</Grid>
							)}
						</Grid>
					</Grid>
				) : (
					<Grid container spacing={3}>
						<Grid item xs={12}>
							<Box
								sx={(theme) => ({
									display: 'flex',
									flexDirection: {
										md: 'row',
										xs: 'column',
									},
									justifyContent: 'flex-end',
									marginTop: '20px',
									marginBottom: 3,
									padding: '20px',
									backgroundColor: theme.palette.primary.dark,
									borderRadius: '8px',
									alignItems: 'center',
									gap: { md: 5, xs: 1 },
								})}
							>
								<Box
									sx={(theme) => ({
										textAlign: 'center',
										padding: '10px',
										borderRadius: '8px',
										backgroundColor:
											theme.palette.background.default,
										boxShadow:
											'0 0 10px rgba(0, 0, 0, 0.1)',
										minWidth: '150px',
										width: {
											md: undefined,
											xs: '100%',
										},
									})}
								>

									<Typography
										variant='h5'
										fontWeight={'bold'}
										color='primary'
									>
										Gross Sales
									</Typography>

									<Typography variant='h4'>
										${parseFloat(+atm + +cash).toFixed(2)}
									</Typography>
								</Box>

								<Box
									sx={(theme) => ({
										textAlign: 'center',
										padding: '10px',
										borderRadius: '8px',
										backgroundColor:
											theme.palette.background.default,
										boxShadow:
											'0 0 10px rgba(0, 0, 0, 0.1)',
										minWidth: '150px',
										width: {
											md: undefined,
											xs: '100%',
										},
									})}
								>
									<Typography
										variant='h5'
										fontWeight={'bold'}
										color='primary'
									>
										Net Sales
									</Typography>
									<Typography variant='h4'>
										$
										{parseFloat(
											+atm +
												+cash -
												+tax -
												+tips_payed -
												+discount
										).toFixed(2)}
									</Typography>
								</Box>
							</Box>
						</Grid>
						<Grid item md={3} xs={12}>
							<TextField
								fullWidth
								label='Branch'
								name='branch'
								onChange={handleBranchChange}
								required
								value={
									dailySale._id
										? dailySale.branch?._id
										: branch?._id
								}
								variant='outlined'
								select
								SelectProps={{
									native: true,
								}}
							>
								{branchOptions.map((branch) => (
									<option
										key={branch?._id}
										value={branch?._id}
									>
										{branch?.name}
									</option>
								))}
							</TextField>
						</Grid>

						<Grid item md={3} xs={12}>
							<SelectDate
								label='Date'
								value={date}
								onChange={handleDateChange}
								fullWidth
							/>
							{/* <LocalizationProvider
									dateAdapter={AdapterDateFns}
								>
									<DesktopDatePicker
										label='Date'
										inputFormat='MM/dd/yyyy'
										value={date}
										onChange={handleDateChange}
										renderInput={(params) => (
											<TextField {...params} />
										)}
									/>
								</LocalizationProvider> */}
						</Grid>
						<Grid item md={3} xs={12}>
							<TextField
								fullWidth
								type='number'
								label='CARD (DEBIT / CREDIT)'
								name='atm'
								onChange={handleAtmChange}
								value={atm}
								variant='outlined'
								InputProps={{
									startAdornment: (
										<InputAdornment position='start'>
											$
										</InputAdornment>
									),
								}}
							/>
						</Grid>

						<Grid item md={3} xs={12}>
							<TextField
								fullWidth
								type='number'
								label='TOTAL CASH'
								name='cash'
								onChange={handleCashChange}
								value={cash}
								variant='outlined'
								InputProps={{
									startAdornment: (
										<InputAdornment position='start'>
											$
										</InputAdornment>
									),
								}}
							/>
						</Grid>

						<Grid item md={3} xs={12}>
							<TextField
								fullWidth
								type='number'
								label='TAX PAID'
								name='tax'
								onChange={handleTaxChange}
								value={tax}
								variant='outlined'
								InputProps={{
									startAdornment: (
										<InputAdornment position='start'>
											$
										</InputAdornment>
									),
								}}
							/>
						</Grid>

						<Grid item md={3} xs={12}>
							<TextField
								fullWidth
								type='number'
								label='TIPS PAID'
								name='tips_payed'
								onChange={handleTipsChange}
								value={tips_payed}
								variant='outlined'
								InputProps={{
									startAdornment: (
										<InputAdornment position='start'>
											$
										</InputAdornment>
									),
								}}
							/>
						</Grid>

						<Grid item md={3} xs={12}>
							<TextField
								fullWidth
								type='number'
								label='DISCOUNT'
								name='discount'
								onChange={handleDiscountChange}
								value={discount}
								variant='outlined'
								InputProps={{
									startAdornment: (
										<InputAdornment position='start'>
											$
										</InputAdornment>
									),
								}}
							/>
						</Grid>

						<Grid item md={3} xs={12}>
							<TextField
								fullWidth
								type='text'
								label='COMMENT'
								name='comment'
								onChange={handleComment}
								value={comment}
								variant='outlined'
							/>
						</Grid>


						<Grid item container spacing={3}>
							{dailySale && (
								<Grid container justifyContent='flex-end' p={2}>
									<Grid item>
										<Button
											id='btn_save'
											name='btn_save'
											color='secondary'
											variant='outlined'
											disabled={isSubmitting}
											sx={{ marginRight: '1em' }}
											onClick={handleCancel}
										>
											Cancel
										</Button>
									</Grid>
									<Grid item>
										<LoadingButton
											loading={isSubmitting}
											onClick={handleSubmit}
											color='primary'
											variant='contained'
											disabled={disabled}
										>
											Save Daily Sale
										</LoadingButton>
									</Grid>
								</Grid>
							)}
						</Grid>
					</Grid>
				)}
			</Box>
			{dailySale._id && (
				<Box sx={{ mt: 5 }}>
					<FilesView
						model='DailySale'
						id={dailySale._id}
						files={files}
						setFiles={setFiles}
						accept={[
							'application/pdf, image/jpeg, image/ief, image/svg+xml, image/x-portable-anymap',
						]}
						subheader={
							'PDF or image files supported, up to 10MB per file'
						}
					/>
				</Box>
			)}
		</Container>
	)
}

DailySalesDetail.propTypes = {
	className: PropTypes.object.isRequired,
	dailySale: PropTypes.object.isRequired,
	setDailySale: PropTypes.func.isRequired,
	newDailySale: PropTypes.func.isRequired,
	setNewDailySale: PropTypes.func.isRequired,
	setView: PropTypes.func.isRequired,
	branches: PropTypes.array.isRequired,
	userBranches: PropTypes.array.isRequired,
	userRoles: PropTypes.array.isRequired,
	canals: PropTypes.array.isRequired,
}

export default DailySalesDetail