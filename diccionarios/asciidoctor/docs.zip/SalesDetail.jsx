import { InputAdornment } from '@mui/material'
import Box from '@mui/material/Box'
import Button from '@mui/material/Button'
import Card from '@mui/material/Card'
import CardContent from '@mui/material/CardContent'
import CardHeader from '@mui/material/CardHeader'
import CircularProgress from '@mui/material/CircularProgress'
import Divider from '@mui/material/Divider'
import Grid from '@mui/material/Grid'
import TextField from '@mui/material/TextField'
import makeStyles from '@mui/styles/makeStyles'
// import { MuiPickersUtilsProvider } from '@material-ui/pickers'
import { AdapterMoment } from '@mui/x-date-pickers/AdapterMoment'
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider'
import { cloneDeep, isEmpty } from 'lodash'
import moment from 'moment'
import 'moment/locale/es' // without this line it didn't work
import React, { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import WeekPicker from '../common/WeekPicker'

import { useNavigate } from 'react-router-dom'
import { createSale, updateSale } from '../../adapters/sales'
import { errorActions } from '../../redux/ducks/errorState'

// moment.locale('es')
// moment.updateLocale('en', {
// 	week: {
// 		dow: 1,
// 	},
// })

const useStyles = makeStyles((theme) => ({
	root: {
		flexGrow: 1,
		backgroundColor: theme.palette.background.paper,
		display: 'flex',
	},
	constactCard: {
		marginTop: theme.spacing(2),
	},
	avatar: {
		marginRight: theme.spacing(2),
	},
	tabs: {
		width: '350px',
		borderRight: `1px solid ${theme.palette.divider}`,
	},
}))

const allAccess = ['owner', 'hr', 'admin']

const SalesDetail = ({
	className,
	sale,
	setSale,
	newSale,
	setNewSale,
	setView,
	branches,
	canals,
	//userBranches,
	userRoles,
	...rest
}) => {

	const classes = useStyles()
	const dispatch = useDispatch()

	const navigate = useNavigate()
	const currentUser = useSelector((state) => state.user.user.data.user)
	const [isSubmitting, setIsSubmitting] = useState(false)
	const [userBranches] = useState(
		currentUser.positions.map((pos) => pos.branch?._id)
	)
	const [branchOptions] = useState(
		currentUser.roles.some((rol) => allAccess.includes(rol)) //si alguno (some) de los roles del usuario pertenece a los definidos en allAccess, devuelvo "true"
			? [...branches] //ve todas las sucursales
			: branches.filter((branch) => userBranches.includes(branch?._id)) //tiene que ver solo sus sucursales
	)

	const [branch, setBranch] = useState(
		sale._id ? sale.branch : branchOptions[0]
	)
	const [week, setWeek] = useState({
		selectedDate: sale._id ? moment(sale.week) : moment().startOf('week'),
	})

	const [arrayCanales, setArrayCanales] = React.useState(
		canals.map((b) => ({
			canal: b._id,
			amount:
				sale._id &&
				sale.canals.filter((c) => b._id === c.canal._id).length > 0
					? sale.canals.filter((c) => b._id === c.canal._id)[0].amount
					: 0,
			name: b.name,
		}))
	)


	const handleBranchChange = (event, index) => {
		// setValue(newValue)
		setBranch(branches.find((b) => b._id === event.target.value))
	}





	if (isEmpty(sale) && !newSale) return <div />

	const handleCanalChange = (target, index) => {
		let newArrayCanales = cloneDeep(arrayCanales)
		newArrayCanales[index].amount = parseFloat(target.value)
		setArrayCanales(newArrayCanales)
	}

	const handleSubmit = async () => {
		try {
			setIsSubmitting(true)


			const values = {
				branch: branch?._id,
				canals: arrayCanales,
				week: week.selectedDate ? week.selectedDate : week,
			}

			sale._id
				? await updateSale(sale._id, values)
				: await createSale(values)
			setArrayCanales(
				canals.map((b) => ({
					canal: b._id,
					amount: 0,
					name: b.name,
				}))
			)
			setIsSubmitting(false)

			dispatch(
				errorActions.setError(
					{
						message: 'The Sale has been saved!',
					},
					true
				)
			)
			if (sale._id) navigate(0)
		} catch (err) {
			console.log(err)
			dispatch(
				errorActions.setError({
					message: err.response.data
						? err.response.data.message
						: 'There was an error on the backend',
				})
			)
			setIsSubmitting(false)
		}
	}


	return (

		<>
			<Card>
				<CardHeader
					title={branch?.name}
					titleTypographyProps={{
						variant: 'h3',
					}}
				/>
				<Divider />

				<CardContent>
					<Grid item container spacing={3}>
						<Grid item md={6} xs={12}>

							{/* Branch */}
							<TextField
								fullWidth
								// disabled
								label='Branch'
								name='branch'
								onChange={handleBranchChange}
								required
								className={classes.input}
								value={branch?._id}
								variant='outlined'
								select
								SelectProps={{
									native: true,
								}}
							>
								{branchOptions.map((branch) => (
									<option
										key={branch?._id}
										value={branch?._id}
									>
										{branch?.name}
									</option>
								))}
							</TextField>
						</Grid>

						<Grid item md={6} xs={12}>

							<LocalizationProvider dateAdapter={AdapterMoment}>
								<WeekPicker
									week={week}
									setWeek={setWeek}
									fullWidth

								/>
							</LocalizationProvider>

						</Grid>

						{arrayCanales.map((c, index) => (
							<Grid key={`canal-${index}`} item md={6} xs={12}>
								<TextField
									key={`canal-${index}`}
									fullWidth
									type='number'
									label={c.name}
									//name={c._id}
									name={c.canal}
									//name={`canals[${c.name}]`}
									onChange={(event) =>
										handleCanalChange(event.target, index)
									}
									value={
										c.amount
										// sale._id
										// 	? c.amount
										// 	: values.amount
									}
									variant='outlined'
									InputProps={{
										startAdornment: (
											<InputAdornment position='start'>
												$
											</InputAdornment>
										),
									}}
								/>
							</Grid>
						))}

					</Grid>
				</CardContent>
			</Card>
		</>
	)
}



export default SalesDetail