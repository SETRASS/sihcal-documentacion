import {
	DataTypeProvider,
	FilteringState,
	IntegratedFiltering,
	IntegratedPaging,
	IntegratedSorting,
	IntegratedSummary,
	PagingState,
	SearchState,
	SortingState,
	SummaryState,
} from '@devexpress/dx-react-grid'
import { GridExporter } from '@devexpress/dx-react-grid-export'
import {
	ExportPanel,
	Grid as GridTable,
	PagingPanel,
	SearchPanel,
	Table,
	TableColumnResizing,
	TableFilterRow,
	TableHeaderRow,
	TableSummaryRow,
	Toolbar,
} from '@devexpress/dx-react-grid-material-ui'
import Visibility from '@mui/icons-material/Visibility'
import Grid from '@mui/material/Grid'
import IconButton from '@mui/material/IconButton'
import Paper from '@mui/material/Paper'
import Tooltip from '@mui/material/Tooltip'
import useMediaQuery from '@mui/material/useMediaQuery'
import { useTheme } from '@mui/styles'
import saveAs from 'file-saver'
import { cloneDeep } from 'lodash'
//import Waiting from '../common/Waiting';
import moment from 'moment'
import { useCallback, useRef, useState } from 'react'
//import useCanal from '../canals/CanalsData'
import { useSelector } from 'react-redux'
//import useSale from './SaleData';
import formatter from '../../config/utils/FormatMoney'
import HeaderCell from '../../styles/tableHeaderStyle'
import { ExportToggleButton } from '../common/ExportToggleButton'
import ManageButton from './ManageButton'


const onSave = (workbook) => {
	workbook.xlsx.writeBuffer().then((buffer) => {
		saveAs(
			new Blob([buffer], { type: 'application/octet-stream' }),
			'Sales Report.xlsx'
		)
	})
}
/* 
const CurrencyFormatter = ({ value }) =>
	value?.toLocaleString('en-US', { style: 'currency', currency: 'USD' })
 */
const CurrencyFormatter = ({ value }) => {
	if (!value || value < 0) {
		value === 0.0
	}
	return value?.toLocaleString('en-US', {
		style: 'currency',
		currency: 'USD',
	})
}

const CurrencyTypeProvider = (props) => (
	<DataTypeProvider formatterComponent={CurrencyFormatter} {...props} />
)
const DateFormatter = ({ value }) => moment(value).format('ll')

const DateTypeProvider = (props) => (
	<DataTypeProvider formatterComponent={DateFormatter} {...props} />
)

const completeAccess = ['admin', 'hr', 'owner']

const SalesTable = ({
	setSale,
	setView,
	BranchArray,
	sales,
	dateRange,
	userRoles,
	...props
}) => {
	//console.log('sales=' + JSON.stringify(sales));
	const theme = useTheme()
	const matchesXS = useMediaQuery(theme.breakpoints.down('sm'))
	const { tenant } = useSelector((state) => state)

	const currentUser = useSelector((state) => state.user.user.data.user)
	const canDelete = currentUser.roles.includes('admin')

	let salesArray = cloneDeep(sales)
	//console.log('SALES ARRAY: ', salesArray);
	const exporterRef = useRef(null)
	const startExport = useCallback(() => {
		exporterRef.current.exportGrid()
	}, [exporterRef])

	const customizeHeader = (worksheet) => {
		const generalStyles = {
			font: { bold: true },
			alignment: { horizontal: 'left' },
		}

		for (let rowIndex = 1; rowIndex < 1; rowIndex += 1) {
			worksheet.mergeCells(rowIndex, 1, rowIndex, 3)
			worksheet.mergeCells(rowIndex, 4, rowIndex, 6)
			Object.assign(worksheet.getRow(rowIndex).getCell(1), generalStyles)
			Object.assign(worksheet.getRow(rowIndex).getCell(3), generalStyles)
		}
		for (let rowIndex = 2; rowIndex < 7; rowIndex += 1) {
			Object.assign(worksheet.getRow(rowIndex).getCell(1), generalStyles)
			Object.assign(worksheet.getRow(rowIndex).getCell(2), generalStyles)
		}
		worksheet.getRow(1).height = 20
		worksheet.getRow(1).getCell(1).font = { bold: true, size: 16 }
		worksheet.getRow(1).getCell(2).font = { bold: true, size: 16 }
		worksheet.getColumn(1).values = [
			`${tenant.config.name} - Sales Report`,
			'',
			'Report Filtered by',
			'Date Initial:',
			'Date End:',
		]

		if (dateRange) {
			worksheet.getColumn(2).values = [
				null,
				null,
				null,
				`${moment(dateRange.initDate).format('L')}`,
				`${moment(dateRange.endDate).format('L')}`,
			]
		} else {
			worksheet.getColumn(2).values = [
				null,
				null,
				null,
				`${moment().format('L')}`,
				`${moment().format('L')}`,
				'Limit 10000 Sale',
			]
		}

		worksheet.getColumn(3).worksheet.addRow({})
		worksheet.addRow({})
		worksheet.mergeCells(9, 1, 9, 15)
		Object.assign(worksheet.getRow(9).getCell(1), {
			font: { bold: true, color: { argb: 'f44336' } },
			alignment: { horizontal: 'left' },
		})

		worksheet.addRow({})
	}

	let columns = [
		{ name: 'actions', title: 'Actions', width: 150 },
		{ name: 'branch', title: 'Branch', width: 250 },
		{ name: 'week', title: 'Week', width: 250 },
		{ name: 'amount', title: 'Amount', width: 250 },
	]
	let tableColumnExtensions = [
		{
			columnName: 'branch',
			width: matchesXS ? '200' : 'auto',
			align: 'left',
		},
		{
			columnName: 'week',
			width: matchesXS ? '200' : 'auto',
			align: 'left',
		},
		{
			columnName: 'amount',
			width: matchesXS ? '200' : 'auto',
			align: 'left',
		},
	]

	const defaultColumnWidths = columns.map((col) => ({
		columnName: col.name,
		width: col.width,
	}))

	const [totalSummaryItems] = useState([
		{ columnName: 'branch', type: 'count' },
		{ columnName: 'amount', type: 'sum' },
	])
	const [currencyColumns] = useState(['amount'])
	const [dateColumns] = useState(['week'])

	const renderActions = (sale) => {
		return (
			<Grid container justifyContent='center'>
				<Grid item xs={4}>
					<Tooltip title='View Sale'>
						<IconButton
							onClick={() => {
								setSale(sale)
								setView('detail')
							}}
							size='large'
						>
							<Visibility color='primary' />
						</IconButton>
					</Tooltip>
				</Grid>
				<Grid item xs={4}>
					{canDelete ? (
						<ManageButton sale={sale} />
					) : (
						<Grid item xs={6}></Grid>
					)}
				</Grid>
			</Grid>
		)
	}

	const CalcularAmount = (canales) => {
		let totalAmount = 0.0
		canales.map((C) => (totalAmount += parseFloat(C.amount)))

		return totalAmount
	}

	//si alguno (some) de los roles del usuario pertenece a los definidos en LimitedAccess, devuelvo "true"
	salesArray = currentUser.roles.some((rol) => completeAccess.includes(rol))
		? salesArray //ve todas las sucursales
		: salesArray.filter((saleE) => BranchArray.includes(saleE.branch?._id)) //tiene que ver solo sus sucursales

	let rows = salesArray.map((item, index) => ({
		branch: item.branch?.name,
		week: item.week, //moment(item.week).format('LL'), //.startOf('week').format('ll'),
		//column.canal.name: item.canals.canal.name,
		amount: parseFloat(CalcularAmount(item.canals)), //formatter.format(CalcularAmount(item.canals)),
		actions: renderActions(item),
	}))

	const exportedRows = salesArray.map((item, index) => ({
		branch: item.branch?.name,
		week: moment(item.week).format('LL'), //.startOf('week').format('ll'),
		amount: formatter.format(CalcularAmount(item.canals)),
		//actions: renderActions(item),
	}))

	return (
		<Paper>
			<GridTable rows={rows} columns={columns}>
				<CurrencyTypeProvider for={currencyColumns} />
				<DateTypeProvider for={dateColumns} />
				<SearchState />
				<FilteringState defaultFilters={[]} />
				<IntegratedFiltering />
				<SortingState
					defaultSorting={[{ columnName: 'week', direction: 'asc' }]}
				/>
				<IntegratedSorting />
				<SummaryState totalItems={totalSummaryItems} />

				<PagingState defaultCurrentPage={0} pageSize={50} />
				<IntegratedPaging />
				<IntegratedSummary />

				<Table columnExtensions={tableColumnExtensions} />
				<TableColumnResizing
					defaultColumnWidths={defaultColumnWidths}
				/>
				<TableHeaderRow
					cellComponent={HeaderCell}
					showSortingControls
				/>
				<TableFilterRow />
				<TableSummaryRow />

				<Toolbar />
				<PagingPanel />
				<SearchPanel messages={{ searchPlaceholder: 'Search...' }} />
				<ExportPanel
					startExport={startExport}
					toggleButtonComponent={ExportToggleButton}
					messages={{ showExportMenu: 'Export to Excel' }}
				/>
			</GridTable>
			<GridExporter
				ref={exporterRef}
				rows={exportedRows}
				columns={columns}
				onSave={onSave}
				customizeHeader={customizeHeader}
			/>
		</Paper>
	)
}


export default SalesTable