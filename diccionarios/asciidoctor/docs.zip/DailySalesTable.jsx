import {
	DataTypeProvider,
	FilteringState,
	IntegratedFiltering,
	IntegratedPaging,
	IntegratedSorting,
	IntegratedSummary,
	PagingState,
	SearchState,
	SortingState,
	SummaryState,
} from '@devexpress/dx-react-grid'
import { GridExporter } from '@devexpress/dx-react-grid-export'
import {
	ExportPanel,
	Grid as GridTable,
	PagingPanel,
	SearchPanel,
	Table,
	TableColumnResizing,
	TableFilterRow,
	TableHeaderRow,
	TableSummaryRow,
	Toolbar,
} from '@devexpress/dx-react-grid-material-ui'

import CommentIcon from '@mui/icons-material/Comment'
import Visibility from '@mui/icons-material/Visibility'
import Grid from '@mui/material/Grid'
import IconButton from '@mui/material/IconButton'
import Paper from '@mui/material/Paper'
import Tooltip from '@mui/material/Tooltip'
import useMediaQuery from '@mui/material/useMediaQuery'
import { useTheme } from '@mui/styles'
import saveAs from 'file-saver'
import { cloneDeep } from 'lodash'
//import Waiting from '../common/Waiting';
import moment from 'moment'
import * as React from 'react'
import { useCallback, useRef, useState } from 'react'
import { useSelector } from 'react-redux'
import formatter from '../../config/utils/FormatMoney'
import HeaderCell from '../../styles/tableHeaderStyle'
import { ExportToggleButton } from '../common/ExportToggleButton'
import { ViewCommentDialog } from '../invoices/components/Detail/components'
import ManageButton from './ManagerButton'

//import useCanal from '../canals/CanalsData'

const onSave = (workbook) => {
	workbook.xlsx.writeBuffer().then((buffer) => {
		saveAs(
			new Blob([buffer], { type: 'application/octet-stream' }),
			'Daily Sale Report.xlsx'
		)
	})
}

const CurrencyFormatter = ({ value }) => {
	if (!value || value < 0) {
		value === 0.0
	}
	return value?.toLocaleString('en-US', {
		style: 'currency',
		currency: 'USD',
	})
}

const CurrencyTypeProvider = (props) => (
	<DataTypeProvider formatterComponent={CurrencyFormatter} {...props} />
)

const DateFormatter = ({ value }) => moment(value).format('ll')

const DateTypeProvider = (props) => (
	<DataTypeProvider formatterComponent={DateFormatter} {...props} />
)

const DailySalesTable = ({
	setDailySale,
	setView,
	BranchArray,
	dailysales,
	dateRange,



	...props
}) => {
	const theme = useTheme()
	const matchesXS = useMediaQuery(theme.breakpoints.down('sm'))
	const { tenant } = useSelector((state) => state)

	//console.log(dailysales);

	const currentUser = useSelector((state) => state.user.user.data.user)
	const canDelete = currentUser.roles.includes('admin')

	// solo pueden ver las cajas de su propia branch
	const LimitedAccess = ['senior', 'manager', 'branch'] // solo pueden ver las ventas de su propia branch

	let dailysalesArray = cloneDeep(dailysales)
	const [dateColumns] = useState(['date'])

	const [openComment, setOpenComment] = React.useState(false)
	const [comment, setComment] = React.useState('')

	const handleClickOpen = () => {
		setOpenComment(true)
	}

	const handleCommentClose = () => {
		setOpenComment(false)
	}

	const exporterRef = useRef(null)
	const startExport = useCallback(() => {
		exporterRef.current.exportGrid()
	}, [exporterRef])

	const customizeHeader = (worksheet) => {
		const generalStyles = {
			font: { bold: true },
			alignment: { horizontal: 'left' },
		}

		for (let rowIndex = 1; rowIndex < 1; rowIndex += 1) {
			worksheet.mergeCells(rowIndex, 1, rowIndex, 3)
			worksheet.mergeCells(rowIndex, 4, rowIndex, 6)
			Object.assign(worksheet.getRow(rowIndex).getCell(1), generalStyles)
			Object.assign(worksheet.getRow(rowIndex).getCell(3), generalStyles)
		}
		for (let rowIndex = 2; rowIndex < 7; rowIndex += 1) {
			Object.assign(worksheet.getRow(rowIndex).getCell(1), generalStyles)
			Object.assign(worksheet.getRow(rowIndex).getCell(2), generalStyles)
		}
		worksheet.getRow(1).height = 20
		worksheet.getRow(1).getCell(1).font = { bold: true, size: 16 }
		worksheet.getRow(1).getCell(2).font = { bold: true, size: 16 }
		worksheet.getColumn(1).values = [
			`${tenant.config.name} - Daily Report`,
			'',
			'Report Filtered by',
			'Date Initial:',
			'Date End:',
		]

		if (dateRange) {
			worksheet.getColumn(2).values = [
				null,
				null,
				null,
				`${moment(dateRange.initDate).format('L')}`,
				`${moment(dateRange.endDate).format('L')}`,
			]
		} else {
			worksheet.getColumn(2).values = [
				null,
				null,
				null,
				`${moment().format('L')}`,
				`${moment().format('L')}`,
				'Limit 10000 Daily Sale',
			]
		}

		worksheet.getColumn(3).worksheet.addRow({})
		worksheet.addRow({})
		worksheet.mergeCells(9, 1, 9, 15)
		Object.assign(worksheet.getRow(9).getCell(1), {
			font: { bold: true, color: { argb: 'f44336' } },
			alignment: { horizontal: 'left' },
		})

		worksheet.addRow({})
	}

	let columns = [
		{ name: 'actions', title: 'Actions', width: 150 },
		{ name: 'branch', title: 'Branch', width: 200 },
		{ name: 'date', title: 'Date', width: 200 },
		{ name: 'username_created', title: 'Creator', width: 200 },
		{ name: 'canal', title: 'Chanel', width: 200 },
		{ name: 'gross_total', title: 'Gross Total', width: 200 },
		{ name: 'net_total', title: 'Net Total', width: 200 },
	]
	const defaultColumnWidths = columns.map((col) => ({
		columnName: col.name,
		width: col.width,
	}))

	let tableColumnExtensions = [
		{
			columnName: 'branch',
			width: matchesXS ? '200' : 'auto',
			align: 'left',
		},
		{
			columnName: 'date',
			width: matchesXS ? '200' : 'auto',
			align: 'left',
		},

		{
			columnName: 'username_created',
			width: matchesXS ? '200' : 'auto',
			align: 'left',
		},
		{
			columnName: 'canal',
			width: matchesXS ? '200' : 'auto',
			align: 'left',
		},
		{
			columnName: 'gross_total',
			width: matchesXS ? '200' : 'auto',
			align: 'left',
		},
		{
			columnName: 'net_total',
			width: matchesXS ? '200' : 'auto',
			align: 'left',
		},
	]

	const [totalSummaryItems] = useState([
		{ columnName: 'branch', type: 'count' },
		{ columnName: 'gross_total', type: 'sum' },
		{ columnName: 'net_total', type: 'sum' },
	])

	const [currencyColumns] = useState(['gross_total', 'net_total'])

	const openCommentdialog = (dailySale) => {
		setOpenComment(true)
		setComment(dailySale.comment)
	}

	const renderActions = (dailysale) => {
		return (
			<Grid container justifyContent='center'>
				<Grid item xs={4}>
					<Tooltip title='View Daily Sale'>
						<IconButton
							onClick={() => {
								setDailySale(dailysale)
								setView('detail')
							}}
							size='large'
						>
							<Visibility color='primary' />
						</IconButton>
					</Tooltip>
				</Grid>
				<Grid item xs={4}>
					<Tooltip title='Comment'>
						<IconButton
							onClick={() => {
								//setDailySale(dailysale)
								openCommentdialog(dailysale)
							}}
							size='large'
						>
							<CommentIcon color='primary' />
						</IconButton>
					</Tooltip>
				</Grid>
				<Grid item xs={4}>
					{canDelete ? (
						<ManageButton dailysale={dailysale} />
					) : (
						<Grid item xs={6}></Grid>
					)}
				</Grid>
			</Grid>
		)
	}

	//funcion para filtrar un objeto, filtramos las invoice en caso de ser rol senior
	/*function filterObj(keys, obj) {
		const newObj = {};
		Object.keys(obj).forEach(key => {
		  if (keys.includes(key)) {
			newObj[key] = obj[key];
		  }
		});
		return newObj;
	  }*/

	//console.log(BranchArray);

	//proceso para mostrar solo las ventas en caso de ser senior, branch, etc
	dailysalesArray = currentUser.roles.some((rol) =>
		LimitedAccess.includes(rol)
	)
		? dailysalesArray.filter((saleE) =>
				BranchArray.includes(saleE.branch?._id)
		  ) //tiene que ver solo sus sucursales
		: dailysalesArray //ve todas las sucursales

	let rows = dailysalesArray.map((item, index) => ({
		branch: item.branch?.name,
		date: item.date, //moment(item.date).format('LL'),
		username_created: item.username_created,
		canal: item.canal?.name || '-',
		gross_total: parseFloat(item.groosTotal), //formatter.format(parseFloat(item.groosTotal)),
		net_total: parseFloat(item.netSale), //formatter.format(parseFloat(item.netSale)),
		actions: renderActions(item),
	}))

	const exportedRows = dailysalesArray.map((item, index) => ({
		branch: item.branch?.name,
		date: moment(item.date).format('LL'),
		username_created: item.username_created,
		canal: item.canal?.name || '-',
		gross_total: formatter.format(parseFloat(item.groosTotal)),
		net_total: formatter.format(parseFloat(item.netSale)),
		//actions: renderActions(item),
	}))

	return (
		<Paper>
			<GridTable rows={rows} columns={columns}>
				<CurrencyTypeProvider for={currencyColumns} />
				<DateTypeProvider for={dateColumns} />
				<SearchState />
				<FilteringState defaultFilters={[]} />
				<IntegratedFiltering />
				<SortingState
					defaultSorting={[{ columnName: 'date', direction: 'asc' }]}
				/>
				<IntegratedSorting />
				<SummaryState totalItems={totalSummaryItems} />

				<PagingState defaultCurrentPage={0} pageSize={50} />
				<IntegratedPaging />
				<IntegratedSummary />
				<Table columnExtensions={tableColumnExtensions} />
				<TableColumnResizing
					defaultColumnWidths={defaultColumnWidths}
				/>
				<TableHeaderRow
					cellComponent={HeaderCell}
					showSortingControls
				/>
				<TableFilterRow />
				<TableSummaryRow />
				<Toolbar />
				<PagingPanel />
				<SearchPanel messages={{ searchPlaceholder: 'Search...' }} />
				<ExportPanel
					startExport={startExport}
					toggleButtonComponent={ExportToggleButton}
					messages={{ showExportMenu: 'Export to Excel' }}
				/>
			</GridTable>
			<GridExporter
				ref={exporterRef}
				rows={exportedRows}
				columns={columns}
				onSave={onSave}
				customizeHeader={customizeHeader}
			/>
			{openComment ? (
				<ViewCommentDialog
					openComment={openComment}
					comment={comment}
					handleCloseComment={handleCommentClose}
				/>
			) : null}
		</Paper>
	)
}

export default DailySalesTable
