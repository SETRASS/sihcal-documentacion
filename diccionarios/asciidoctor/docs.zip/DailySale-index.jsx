import Box from '@mui/material/Box'
import Container from '@mui/material/Container'
import moment from 'moment-timezone'
import { useState } from 'react'
import { useSelector } from 'react-redux'
import useBranches from '../branches/branchesData'
import DailySalesDetail from './DailySalesDetail'
import DailySalesTable from './DailySalesTable'
import Toolbar from './Toolbar'

import useCanal from '../canals/CanalsData'
import Waiting from '../common/Waiting'
import useDailySale from './DailySaleData'


const DailySale = () => {
	const [view, setView] = useState('table')
	const [dailySale, setDailySale] = useState({})

	const [newDailySale, setNewDailySale] = useState(false)
	const { user } = useSelector((state) => state.user.user.data)
	const { timezone } = useSelector((state) => state.tenant.config.config)
	const { canals } = useCanal()

	const { branches } = useBranches()

	const startOfMonth = moment()
		.tz(timezone, true)
		.startOf('month')
		.format('YYYY-MM-DD hh:mm')
	const endOfMonth = moment()
		.tz(timezone, true)
		.endOf('month')
		.format('YYYY-MM-DD hh:mm')

	const [dateRange, setDateRange] = useState({
		initDate: moment().tz(timezone, true).startOf('month'),
		endDate: moment().tz(timezone, true).endOf('month'),
	})

	const { loading, dailysales } = useDailySale(
		dateRange
			? `?limit=10000&&sort=-date&&initDate=${dateRange.initDate.format(
					'YYYY-MM-DD HH:mm ZZ'
			  )}&&endDate=${dateRange.endDate.format('YYYY-MM-DD HH:mm ZZ')}`
			: `?limit=10000&&sort=-date&&initDate=${startOfMonth}&&endDate=${endOfMonth}`
	)

	const userBranch = user.positions
	const userRoles = user.roles
	const BranchArray = []

	userBranch.forEach((element) => {
		BranchArray.push(element.branch?._id)
	})

	const renderContent = () => {
		switch (view) {
			case 'table':
				return (
					<DailySalesTable
						setDailySale={setDailySale}
						setView={setView}
						dailysales={dailysales}
						userRoles={userRoles}
						BranchArray={BranchArray}
						dateRange={dateRange}
					/>
				)
			case 'detail':
				return (
					<DailySalesDetail
						newDailySale={newDailySale}
						setNewDailySale={setNewDailySale}
						dailySale={dailySale}
						setDailySale={setDailySale}
						setView={setView}
						branches={branches}
						userBranches={BranchArray}
						userRoles={userRoles}
						canals={canals}
					/>
				)
			default:
				break
		}
	}

	return (
		<Container maxWidth={false}>
			<Box mt={3}>
				<Toolbar
					setView={setView}
					view={view}
					setNewDailySale={setNewDailySale}
					setDailySale={setDailySale}
					dateRange={dateRange}
					setDateRange={setDateRange}
				/>
			</Box>
			<Box mt={3}> {loading ? <Waiting /> : renderContent()} </Box>
		</Container>
	)
}

export default DailySale